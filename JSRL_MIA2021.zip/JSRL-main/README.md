# JSRL
This is a code implemention of the JSRL method proposed in the manuscipt "Assessing Clinical Progression from Subjective Cognitive Decline to Mild Cognitive Impairment with Incomplete Multi-modal Neuroimages".
